A Pen created at CodePen.io. You can find this one at https://codepen.io/devkumar123_codepen/pen/bvMpPJ.

 This is a tribute page  to  The great man Karoly Takacs.